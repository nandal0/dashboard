import React, { useEffect, useState } from 'react'
import PostList from './PostList'

const link='https://rickandmortyapi.com/api/character/?page=2'
const App = () => {
    
    const [post,setPost]=useState([])

    const fetchDAta =async()=>{
      
        const res=await fetch(`${link}`)
        
        const data= await res.json()
        console.log(data)
        setPost(data.results)
    }
    useEffect(()=>{
        fetchDAta()
    },[])
    return (
        <div>
            <p  class="z">
            Rick and Morty 
            </p>
            <PostList post={post}/>
        </div>
    )
}

export default App
