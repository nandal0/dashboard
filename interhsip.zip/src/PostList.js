import React from 'react'
import './PostList.css'

const PostList = ({post}) => {
    console.log(post)
    return (
        <div class="c">

      {post.map((pos) =>{
           return (     
            <div key={pos.id} class="card" style={{width: "18rem"}}>
            <img src={pos.image} class="card-img-top" alt="..."/>
            <div class="card-body">
              <h5 class="card-title">{pos.name}</h5>
              <p class="card-text">
                  <i><b>Gender: </b></i>{pos.gender}<br />
                  <b><i>Species </i></b>{pos.species}<br />
                  <b><i>Origin </i></b>{pos.origin.name}<br />
                  <b><i>Status </i></b>{pos.status}<br />
                  <b><i>episode </i></b>{pos.episode.length}<br />
                  
              </p>
            </div>
            
            
          </div>
              )
      })}
            
        </div>
    )
}

export default PostList
